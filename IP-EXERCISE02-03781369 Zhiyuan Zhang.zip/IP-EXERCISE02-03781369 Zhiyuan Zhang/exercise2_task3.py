import cv2
import numpy as np
import matplotlib.pyplot as plt

def manual_convolution(image, kernel):
    m, n = image.shape
    km, kn = kernel.shape
    pad_image = np.pad(image, ((km // 2, km // 2), (kn // 2, kn // 2)), mode='constant')
    result = np.zeros_like(image, dtype=np.float64)

    for i in range(1, m):
        for j in range(1, n):
            result[i, j] = np.sum(pad_image[i-(km//2):(1+i+km//2), j-(kn//2):(1+j+(kn//2))] * kernel)
    
    return result

# read the image of old town 
image_path = 'old_town.jpg' 
image = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)

# check if the image is read into the code
if image is None:
    print("Error: Could not read the image.")
else:
    # Sobel mask
    kernel_x = np.array([[-1, 0, 1], [-2, 0, 2], [-1, 0, 1]])
    kernel_y = np.array([[-1, -2, -1], [0, 0, 0], [1, 2, 1]])

    # gradient x and y after using sobel 
    gradient_x = manual_convolution(image, kernel_x)
    gradient_y = manual_convolution(image, kernel_y)
    sobel_result = np.sqrt(gradient_x**2 + gradient_y**2)
    sobel_phase = np.arctan2(gradient_y, gradient_x)  # Compute phase angle map

    # gauss fliter
    smoothed_image = cv2.GaussianBlur(image, (5, 5), 0)

    # manual Laplacian
    kernel_laplacian = np.array([[0, 1, 0], [1, -4, 1], [0, 1, 0]])
    laplacian = manual_convolution(smoothed_image, kernel_laplacian)

    # AND between laplacian and original image
    laplacian_and_original = cv2.bitwise_and(laplacian.astype(np.uint8), image)

    # Otsu
    _, thresholded_image = cv2.threshold(laplacian_and_original, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)

    # image shown 
    plt.subplot(2, 5, 1), plt.imshow(image, cmap='gray')
    plt.title('Original Image'), plt.xticks([]), plt.yticks([])

    plt.subplot(2, 5, 2), plt.imshow(gradient_x, cmap='gray')
    plt.title('Gradient X'), plt.xticks([]), plt.yticks([])

    plt.subplot(2, 5, 3), plt.imshow(gradient_y, cmap='gray')
    plt.title('Gradient Y'), plt.xticks([]), plt.yticks([])

    plt.subplot(2, 5, 4), plt.imshow(sobel_result, cmap='gray')
    plt.title('Sobel'), plt.xticks([]), plt.yticks([])

    plt.subplot(2, 5, 5), plt.imshow(sobel_phase, cmap='gray')  # Display Sobel phase in grayscale
    plt.title('Sobel Phase'), plt.xticks([]), plt.yticks([])

    plt.subplot(2, 5, 6), plt.imshow(smoothed_image, cmap='gray')
    plt.title('Smoothed Image'), plt.xticks([]), plt.yticks([])

    plt.subplot(2, 5, 7), plt.imshow(laplacian, cmap='gray')
    plt.title('Laplacian'), plt.xticks([]), plt.yticks([])

    plt.subplot(2, 5, 8), plt.imshow(laplacian_and_original, cmap='gray')
    plt.title('Laplacian AND Original'), plt.xticks([]), plt.yticks([])

    plt.subplot(2, 5, 9), plt.imshow(thresholded_image, cmap='gray')
    plt.title('Otsu Thresholded Image'), plt.xticks([]), plt.yticks([])

    plt.show()
