import cv2
import numpy as np
import matplotlib.pyplot as plt

# read images as original image and get size of 32692_5336.tif
image_path = '32692_5336.tif'
original_image = cv2.imread(image_path, cv2.IMREAD_COLOR)
image_height, image_width, _ = original_image.shape
pixel_resolution = 0.4

# Get the coordinate of the lower right corner of subset
lower_right_corner_utm = (693000.0, 5336000.0)

# make functions to create the subset and calculate the world coordinates
def subset(image, upper_left_corner, nu, nv):
    return image[upper_left_corner[1]:upper_left_corner[1] + nv, upper_left_corner[0]:upper_left_corner[0] + nu]

def calculate_world_coordinates(upper_left_corner_utm, pixel_resolution, x, y):
    world_x = upper_left_corner_utm[0] + x * pixel_resolution
    world_y = upper_left_corner_utm[1] - y * pixel_resolution
    return world_x, world_y

# the parameters of ps and subset.
ps = (900, 1000)
nu, nv = 1200, 800
ps_world_x = lower_right_corner_utm[0] - (image_width - ps[0]) * pixel_resolution
ps_world_y = lower_right_corner_utm[1] - (image_height - ps[1]) * pixel_resolution
ps_world_coordinates = (ps_world_x, ps_world_y)

# calculate the upper left position
subset_upper_left_pixel = (ps[0], ps[1])

# calculate the upper left world coordinate
subset_upper_left_utm = calculate_world_coordinates(lower_right_corner_utm, pixel_resolution, subset_upper_left_pixel[0], subset_upper_left_pixel[1])

# create the subset
subset_image = subset(original_image, subset_upper_left_pixel, nu, nv)

# draw points P1, P2, P3 on the subset
cv2.circle(subset_image, (1050, 229), 5, (0, 0, 255), -1)  # P1 in red
cv2.circle(subset_image, (72, 387), 5, (0, 255, 0), -1)    # P2 in green
cv2.circle(subset_image, (493, 633), 5, (255, 0, 0), -1)   # P3 in blue

# draw text P1, P2, P3 on the subset
cv2.putText(subset_image, 'P1', (1050, 229), cv2.FONT_HERSHEY_SIMPLEX, 2.5, (0, 0, 255), 3, cv2.LINE_AA)
cv2.putText(subset_image, 'P2', (72, 387), cv2.FONT_HERSHEY_SIMPLEX, 2.5, (0, 255, 0), 3, cv2.LINE_AA)
cv2.putText(subset_image, 'P3', (493, 633), cv2.FONT_HERSHEY_SIMPLEX, 2.5, (255, 0, 0), 3, cv2.LINE_AA)

# display the subset with points and labels
plt.imshow(cv2.cvtColor(subset_image, cv2.COLOR_BGR2RGB))
plt.title('Subset with Points')
plt.show()

# figure
plt.figure(figsize=(12, 5))

# show ps and susbet
plt.imshow(cv2.cvtColor(original_image, cv2.COLOR_BGR2RGB))
plt.scatter([1050+ ps[0], 72+ ps[0], 493+ ps[0]], [229+ ps[1], 387+ ps[1], 633+ ps[1]], color='red', marker='x', label='Points in the original image')
plt.plot([ps[0], ps[0] + nu, ps[0] + nu, ps[0], ps[0]], [ps[1], ps[1], ps[1] + nv, ps[1] + nv, ps[1]], color='red', linewidth=2, label='Subset boundary')

# show p1, p2, p3
plt.text(1050 + ps[0], 229 + ps[1], 'P1', color='yellow', fontsize=12, ha='left', va='bottom')
plt.text(72 + ps[0], 387 + ps[1], 'P2', color='yellow', fontsize=12, ha='left', va='bottom')
plt.text(493 + ps[0], 633 + ps[1], 'P3', color='yellow', fontsize=12, ha='left', va='bottom')
plt.title('Original Image')
plt.legend()
plt.show()
