import numpy as np
import cv2
import matplotlib.pyplot as plt

def read_image_from_txt(file_path):
    with open(file_path, 'r') as file:
        lines = file.readlines()
        image = np.array([list(map(int, line.split())) for line in lines], dtype=np.uint8)
    return image

def median(arr):
    sorted_arr = np.sort(arr)
    length = len(sorted_arr)
    
    if length % 2 == 1:
        return sorted_arr[length // 2]
    else:
        mid1 = sorted_arr[length // 2 - 1]
        mid2 = sorted_arr[length // 2]
        return (mid1 + mid2) / 2
        #return mid2

def compute_mean_and_median(values):
    mean_value = np.mean(values)
    median_value = median(values)
    return mean_value, median_value

def convolution(image, kernel):
    # Convert to uint8 before applying cv2.filter2D
    return cv2.filter2D(np.uint8(image), -1, kernel)

def addBorder(image, border_size):
    return cv2.copyMakeBorder(image, border_size, border_size, border_size, border_size, cv2.BORDER_CONSTANT, value=0)

def medianImg(image):
    border_size = 1
    padded_image = addBorder_mirror(image, border_size,border_size)
    result_image = np.zeros_like(image)

    for i in range(border_size, image.shape[0] + border_size):
        for j in range(border_size, image.shape[1] + border_size):
            neighbors = padded_image[i - 1:i + 2, j - 1:j + 2].flatten()
            result_image[i - border_size, j - border_size] = median(neighbors)

    return result_image

def addBorder_mirror(img, br, bc):
    row,col = img.shape
    imgOut = np.zeros((row +2*br,col+2*bc),np.uint8)
    r = 0
    c = 0
    for px in np.nditer(imgOut[:,:], op_flags=["readwrite"]):
        rI = br - r
        cI = bc - c
        if rI < 0:
            rI = r - br 
        if rI >= row:
            rI = row - (rI - row) - 2
        if cI < 0:
            cI = c - bc
        if cI >= col:
            cI = col - (cI - col) - 2
        px[...] = img[rI,cI]
        c+=1
        if c >= imgOut.shape[1]:
            c=0
            r+=1
    return imgOut

# Read chessboard image
chessboard = np.array([[0, 0, 0, 0, 0, 255, 255, 255, 255, 255],
                       [0, 0, 0, 0, 0, 255, 255, 255, 255, 255],
                       [0, 0, 0, 0, 0, 255, 255, 255, 255, 255],
                       [0, 0, 0, 0, 0, 255, 255, 255, 255, 255],
                       [0, 0, 0, 0, 0, 255, 255, 255, 255, 255],
                       [255, 255, 255, 255, 255, 0, 0, 0, 0, 0],
                       [255, 255, 255, 255, 255, 0, 0, 0, 0, 0],
                       [255, 255, 255, 255, 255, 0, 0, 0, 0, 0],
                       [255, 255, 255, 255, 255, 0, 0, 0, 0, 0],
                       [255, 255, 255, 255, 255, 0, 0, 0, 0, 0]], dtype=np.uint8)

# Read chessboard_noisy from txt file
chessboard_noisy_path = 'chessboard_noisy.txt'
chessboard_noisy = read_image_from_txt(chessboard_noisy_path)

# Create a 3x3 kernel for mean value
mean_kernel = np.ones((3, 3), dtype=np.float32) / 9

# Convert the kernel to the correct format
mean_kernel = np.float32(mean_kernel)

# Compute mean image
mean_image = convolution(chessboard, mean_kernel)
mean_imagenoisy =convolution(chessboard_noisy,mean_kernel)
# Compute median image
median_image = medianImg(chessboard)
median_imagenoisy =medianImg(chessboard_noisy)
# Compute mean and median values for the chessboard array
mean_chessboard, median_chessboard = compute_mean_and_median(chessboard.flatten())
mean_chessboardnoisy, median_chessboardnoisy = compute_mean_and_median(chessboard_noisy.flatten())
# Display the results in one figure
plt.figure(figsize=(12, 8))

plt.subplot(2, 3, 1), plt.imshow(chessboard, cmap='gray')
plt.title(f'Original Chessboard\nMean: {mean_chessboard:.2f}, Median: {median_chessboard:.2f}'), plt.axis('off')

plt.subplot(2, 3, 2), plt.imshow(mean_image, cmap='gray')
plt.title(f'Mean Image'), plt.axis('off')

plt.subplot(2, 3, 3), plt.imshow(median_image, cmap='gray')
plt.title(f'Median Image'), plt.axis('off')

plt.subplot(2, 3, 4), plt.imshow(chessboard_noisy, cmap='gray')
plt.title(f'Original Chessboard\nMean: {mean_chessboardnoisy:.2f}, Median: {median_chessboardnoisy:.2f}'), plt.axis('off')

plt.subplot(2, 3, 5), plt.imshow(mean_imagenoisy, cmap='gray')
plt.title(f'Mean Image'), plt.axis('off')

plt.subplot(2, 3, 6), plt.imshow(median_imagenoisy, cmap='gray')
plt.title(f'Median Image'), plt.axis('off')
# Given list of values
values = [19.7, 556.3, 23.2, 27.5, 16.3, 21.0, 27.2, 495.0, 25.3]
mean_values, median_values = compute_mean_and_median(values)
print(f'Mean of values of given array with 9 elements: {mean_values:.2f}')
print(f'Median of values of given array with 9 elements: {median_values:.2f}')

plt.show()
