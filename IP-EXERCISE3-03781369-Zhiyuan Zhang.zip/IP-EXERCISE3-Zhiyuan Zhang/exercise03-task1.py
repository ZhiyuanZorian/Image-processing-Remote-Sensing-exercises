from IP_ex3_func import addBorder as pad
from IP_ex3_func import convolution as conv
from IP_ex3_func import sobel
from IP_ex3_func import non_max_suppresion as suppresion
import cv2
import numpy as np
import matplotlib.pyplot as plt

def hough_transform(image, alpha_range, d_range):
    # Edge detection (Sobel)
    [edges_x, edges_y, direction, magnitude] = sobel(image)
    edges = suppresion(direction, magnitude, 4)  # You can adjust the threshold as needed
    [n, m] = np.shape(edges)
    # Hough Transform
    accumulator = np.zeros((len(alpha_range), len(d_range)), dtype=np.uint64)
    edges_result = np.zeros((n, m), dtype=np.uint8)  # Corrected the initialization of edges_result
    for i in range(image.shape[0]):
        for j in range(image.shape[0]):
           if edges[i,j] > 0: #judge if edge[i,j]!=0
            for a_idx, alpha in enumerate (alpha_range): #get the index of alpha and the value of alpha in the alpha_range by function enumerate
                d = int(j * np.cos(np.radians(alpha)) + i * np.sin(np.radians(alpha)))#calculate the value of d according to alpha
                d_idx = np.argmin(abs(d_range-d))#get the index of d, here is important: d may not be an intergal, so the minium "d" in the d value should be assigned here
                accumulator[a_idx,d_idx] += 1#here the np.argmin is used to get the d index, then the accumulator is added up.
    return accumulator

## images for task1
#image 01
image_ptsInRow = np.zeros((40,40))
image_ptsInRow[5,0] = 1
image_ptsInRow[15,10] = 1
image_ptsInRow[25,20] = 1
image_ptsInRow[35,30] = 1
image1=image_ptsInRow

# test points image 02
image_4pts = np.zeros((40,40))
image_4pts[20,7] = 1
image_4pts[7,20] = 1
image_4pts[20,33] = 1
image_4pts[33,20] = 1
image2=image_4pts

# test points image 03
image_noise = np.zeros((40,40))
image_noise[np.random.randint(37, size=(23,1)),np.random.randint(37, size=(23,1))] = 1
image3=image_noise

# test lines image 04
image_lines = np.zeros((40,40))
image_lines[:,15] = 1
for ii in range(1,40,1):
    image_lines[ii,-ii] = 1
image4=image_lines

# Hough parameters
alpha_range = np.arange(-90, 90.0, 1)
d_max = int(np.sqrt(image1.shape[0]**2 + image1.shape[1]**2))
#d_max = int(image1.shape[0]**2 + image1.shape[1]**2)
d_range = np.arange(-d_max, d_max+1, 1)

# Perform Hough Transform for each image
accumulator1 = hough_transform(image1, alpha_range, d_range)
accumulator2 = hough_transform(image2, alpha_range, d_range)
accumulator3 = hough_transform(image3, alpha_range, d_range)
accumulator4 = hough_transform(image4, alpha_range, d_range)

[distance_1,alpha_1] = np.unravel_index(np.argmax(accumulator1), accumulator2.shape)
[distance_2,alpha_2] = np.unravel_index(np.argmax(accumulator2), accumulator2.shape)
[distance_3,alpha_3] = np.unravel_index(np.argmax(accumulator3), accumulator3.shape)
[distance_4,alpha_4] = np.unravel_index(np.argmax(accumulator4), accumulator4.shape)

# Result Output
print("The most possible point after the hough transformation")
print("The most possible distance for image1:",distance_1, "The most possible angle for image1:",alpha_1)
print("The most possible distance for image2:",distance_2, "The most possible angle for image2:",alpha_2)
print("The most possible distance for image3:",distance_3, "The most possible angle for image3:",alpha_3)
print("The most possible distance for image4:",distance_4, "The most possible angle for image4:",alpha_4)

# Display the Hough Transform results (histograms)
plt.figure(figsize=(15, 5))

plt.subplot(2, 4, 1)
plt.imshow(image1, cmap='gray')
plt.title('Image 1'), plt.xticks([]), plt.yticks([])

plt.subplot(2, 4, 2)
plt.imshow(accumulator1.T, cmap='gray', extent=[alpha_range[0], alpha_range[-1], d_range[0], d_range[-1]], aspect='auto')
plt.title('Hough Transform Image 1'), plt.xlabel('alpha'), plt.ylabel('d')

plt.subplot(2, 4, 3)
plt.imshow(image2, cmap='gray')
plt.title('Image 2'), plt.xticks([]), plt.yticks([])

plt.subplot(2, 4, 4)
plt.imshow(accumulator2.T, cmap='gray', extent=[alpha_range[0], alpha_range[-1], d_range[0], d_range[-1]], aspect='auto')
plt.title('Hough Transform Image 2'), plt.xlabel('alpha'), plt.ylabel('d')

plt.subplot(2, 4, 5)
plt.imshow(image3, cmap='gray')
plt.title('Image 3'), plt.xticks([]), plt.yticks([])

plt.subplot(2, 4, 6)
plt.imshow(accumulator3.T, cmap='gray', extent=[alpha_range[0], alpha_range[-1], d_range[0], d_range[-1]], aspect='auto')
plt.title('Hough Transform Image 3'), plt.xlabel('alpha'), plt.ylabel('d')

plt.subplot(2, 4, 7)
plt.imshow(image4, cmap='gray')
plt.title('Image 4'), plt.xticks([]), plt.yticks([])

plt.subplot(2, 4, 8)
plt.imshow(accumulator4.T, cmap='gray', extent=[alpha_range[0], alpha_range[-1], d_range[0], d_range[-1]], aspect='auto')
plt.title('Hough Transform Image 4'), plt.xlabel('alpha'), plt.ylabel('d')

plt.show()

