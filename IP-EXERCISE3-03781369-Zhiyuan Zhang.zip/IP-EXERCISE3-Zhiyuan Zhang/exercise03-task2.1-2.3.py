from IP_ex3_func import addBorder as pad
from IP_ex3_func import convolution as conv
from IP_ex3_func import sobel
from IP_ex3_func import non_max_suppresion as suppresion
from scipy.signal import find_peaks
import cv2
import numpy as np
import matplotlib.pyplot as plt

def gaussian_blur(image, kernel_size):
    return cv2.GaussianBlur(image, (kernel_size, kernel_size), 0)

def manual_edge_connection(edges, threshold_percentage):
    threshold_value = np.max(edges) * threshold_percentage
    edges[edges < threshold_value] = 0

    # Perform manual edge connection (simplified)
    for i in range(1, edges.shape[0] - 1):
        for j in range(1, edges.shape[1] - 1):
            if edges[i, j] > 0:
                neighbors = edges[i-1:i+2, j-1:j+2]
                if np.max(neighbors) > 0:
                    edges[i, j] = 255

    return edges

def hough_transform(image, alpha_range, d_range):
    # Edge detection (Sobel)
    [edges_x, edges_y, direction, magnitude] = sobel(image)
    edges = suppresion(direction, magnitude, 4)  # You can adjust the threshold as needed
    [n, m] = np.shape(edges)
    # Hough Transform
    accumulator = np.zeros((len(alpha_range), len(d_range)), dtype=np.uint64)
    edges_result = np.zeros((n, m), dtype=np.uint8)  # Corrected the initialization of edges_result
    for i in range(image.shape[0]):
        for j in range(image.shape[1]):
           if edges[i,j] > 0: #judge if edge[i,j]!=0
            for a_idx, alpha in enumerate (alpha_range): #get the index of alpha and the value of alpha in the alpha_range by function enumerate
                d = int(j * np.cos(np.radians(alpha)) + i * np.sin(np.radians(alpha)))#calculate the value of d according to alpha
                d_idx = np.argmin(abs(d_range-d))#get the index of d, here is important: d may not be an intergal, so the minium "d" in the d value should be assigned here
                accumulator[a_idx,d_idx] += 1#here the np.argmin is used to get the d index, then the accumulator is added up.
    return accumulator


image_path = 'building.jpg'
image = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)

if image is None:
    print("Error: Could not read the image.")
else:
    # Apply Gaussian smoothing
    smoothed_image = gaussian_blur(image, kernel_size=5)

    [gradient_x, gradient_y, direction, magnitude] = sobel(smoothed_image)
    edge = suppresion(direction, magnitude, 5)

    # Manual edge connection
    connected_edges = manual_edge_connection(magnitude.copy(), threshold_percentage=0.34)

    # Use Canny algorithm for comparison
    canny_edges = cv2.Canny(smoothed_image, 50, 150)
    
    # Hough parameters
    alpha_range = np.arange(-90.0, 90.0, 1)
    d_max = int(np.sqrt(image.shape[0]**2 + image.shape[1]**2))
    d_range = np.arange(-d_max, d_max + 1, 1)


    # Use hough
    hough=hough_transform(connected_edges,alpha_range,d_range)
    hough2=hough_transform(edge,alpha_range,d_range)
    hough3=hough_transform(magnitude,alpha_range,d_range)
    #results
    plt.figure(1)
    plt.subplot(2, 4, 1), plt.imshow(image, cmap='gray')
    plt.title('Original Image'), plt.xticks([]), plt.yticks([])

    plt.subplot(2, 4, 2), plt.imshow(smoothed_image, cmap='gray')
    plt.title('Smoothed Image'), plt.xticks([]), plt.yticks([])

    plt.subplot(2, 4, 3), plt.imshow(gradient_x, cmap='gray')
    plt.title('Gradient X'), plt.xticks([]), plt.yticks([])

    plt.subplot(2, 4, 4), plt.imshow(gradient_y, cmap='gray')
    plt.title('Gradient Y'), plt.xticks([]), plt.yticks([])

    plt.subplot(2, 4, 5), plt.imshow(magnitude, cmap='gray')
    plt.title('magnitude'), plt.xticks([]), plt.yticks([])

    plt.subplot(2, 4, 6), plt.imshow(edge, cmap='gray')
    plt.title('after suppression'), plt.xticks([]), plt.yticks([])

    plt.subplot(2, 4, 7), plt.imshow(connected_edges, cmap='gray')
    plt.title('Connected Edges'), plt.xticks([]), plt.yticks([])
    
    plt.subplot(2, 4, 8), plt.imshow(hough, cmap='gray')
    plt.title('Hough result of Edges'), plt.xticks([]), plt.yticks([])
    plt.show()

    
