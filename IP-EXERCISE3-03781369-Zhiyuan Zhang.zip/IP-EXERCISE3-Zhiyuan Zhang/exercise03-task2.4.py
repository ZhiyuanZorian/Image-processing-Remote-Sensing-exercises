from IP_ex3_func import addBorder as pad
from IP_ex3_func import convolution as conv
from IP_ex3_func import sobel
from IP_ex3_func import non_max_suppresion as suppresion
import cv2
import numpy as np
import matplotlib.pyplot as plt

def gaussian_blur(image, kernel_size):
    return cv2.GaussianBlur(image, (kernel_size, kernel_size), 0)

def manual_edge_connection(edges, threshold_percentage):
    threshold_value = np.max(edges) * threshold_percentage
    edges[edges < threshold_value] = 0

    # Perform manual edge connection (simplified)
    for i in range(1, edges.shape[0] - 1):
        for j in range(1, edges.shape[1] - 1):
            if edges[i, j] > 0:
                neighbors = edges[i-1:i+2, j-1:j+2]
                if np.max(neighbors) > 0:
                    edges[i, j] = 255

    return edges

def hough_transform(image, alpha_range, d_range):
    # Edge detection (Sobel)
    [edges_x, edges_y, direction, magnitude] = sobel(image)
    edges = suppresion(direction, magnitude, 4)  # You can adjust the threshold as needed
    [n, m] = np.shape(edges)
    # Hough Transform
    accumulator = np.zeros((len(alpha_range), len(d_range)), dtype=np.uint64)
    edges_result = np.zeros((n, m), dtype=np.uint8)  # Corrected the initialization of edges_result
    for i in range(image.shape[0]):
        for j in range(image.shape[1]):
           if edges[i,j] > 0: #judge if edge[i,j]!=0
            for a_idx, alpha in enumerate (alpha_range): #get the index of alpha and the value of alpha in the alpha_range by function enumerate
                d = int(j * np.cos(np.radians(alpha)) + i * np.sin(np.radians(alpha)))#calculate the value of d according to alpha
                d_idx = np.argmin(abs(d_range-d))#get the index of d, here is important: d may not be an intergal, so the minium "d" in the d value should be assigned here
                accumulator[a_idx,d_idx] += 1#here the np.argmin is used to get the d index, then the accumulator is added up.
    return accumulator

def find_top_lines(hough, alpha_range, d_range, num_lines):   #here the alpha range is one of the three intervals
    max_indices = np.unravel_index(np.argsort(hough.flatten())[-num_lines:], hough.shape)  #get the first two biggest points from accumulator
    lines = [] #the max_indices contains indices of two biggest points in the interval
    for i in range(num_lines): #num_lines = 2: two points in accumulator means 2 lines in the image space.
        alpha_index, d_index = max_indices[0][i], max_indices[1][i] #get the index and of alpha and distance
        alpha_value, d_value = alpha_range[alpha_index], d_range[d_index] #get the value of a and d according to alpha_range and d_range
        #hough_value = hough[alpha_index, d_index]
        x_values = np.arange(image.shape[1]) #the reverse transformation from hough to image space, the line should be present in x and y 
        y_values = np.round((d_value - x_values * np.cos(np.radians(alpha_value))) / np.sin(np.radians(alpha_value))).astype(int) # y = d - x*cos(alpha)/sin(alpha)
        valid_points = np.where((y_values >= 0) & (y_values < image.shape[0])) #select the desired points in the line, the points should not exceed the boundary of the original image
        x_values, y_values = x_values[valid_points], y_values[valid_points] #assign the values
        lines.append((x_values, y_values))
    return lines

def plot_lines_on_image(image, lines):
    if image.ndim == 2:
        image_with_lines = cv2.cvtColor(image, cv2.COLOR_GRAY2RGB)
    else:
        image_with_lines = image.copy()

    for line in lines:
        for j in range(len(line[0])-1):
            cv2.line(image_with_lines, (line[0][j], line[1][j]), (line[0][j+1], line[1][j+1]), (255, 0, 0), 2)
    return image_with_lines

image_path = 'building.jpg'
image = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
image_rgb = cv2.imread(image_path)
image_with_lines=image_rgb

if image is None:
    print("Error: Could not read the image.")
else:
    # Apply Gaussian smoothing
    smoothed_image = gaussian_blur(image, kernel_size=5)

    [gradient_x, gradient_y, direction, magnitude] = sobel(smoothed_image)
    edge = suppresion(direction, magnitude, 5)

    # Manual edge connection
    connected_edges = manual_edge_connection(magnitude.copy(), threshold_percentage=0.34)

    # Hough parameters
    alpha_range = np.arange(-90.0, 90.0, 1)
    d_max = int(np.sqrt(image.shape[0]**2 + image.shape[1]**2))
    d_range = np.arange(-d_max, d_max + 1, 1)

    # Use hough
    hough = hough_transform(connected_edges, alpha_range, d_range)

    # Find and plot top lines for each α range interval
    num_lines_per_interval = 2
    intervals = np.array_split(alpha_range, 3)

    plt.figure(figsize=(15, 15))
    for i, interval in enumerate(intervals, 1):
        interval_hough = hough_transform(connected_edges, interval, d_range)
        lines = find_top_lines(interval_hough, interval, d_range, num_lines_per_interval)
        image_with_lines = plot_lines_on_image(image_with_lines, lines)

    plt.imshow(image_with_lines)
    plt.title('final result')
    plt.show()
