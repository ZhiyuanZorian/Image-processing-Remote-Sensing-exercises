function correctedImage = GeometricCorrection(originalImage_path,referenceImage_path)
%����У��
originalImage = im2double(imread(originalImage_path));
referenceImage = im2double(imread(referenceImage_path));
figure('Name','��ѡ��3����Ӧ��'),
subplot(1,2,1);
imshow(originalImage);
title('ԭʼͼ��');
subplot(1,2,2);
imshow(referenceImage);
title('�ο�ͼ��');
[x,y] = ginput(6);
close all;
x1 = x(1);X1 = x(2);x2 = x(3);X2 = x(4);x3 = x(5);X3 = x(6);
y1 = y(1);Y1 = y(2);y2 = y(3);Y2 = y(4);y3 = y(5);Y3 = y(6);
T = [1,1,1;X1,X2,X3;Y1,Y2,Y3];
a = [x1,x2,x3]/T;b = [y1,y2,y3]/T;
a0 = a(1);a1 = a(2);a2 = a(3);b0 = b(1);b1 = b(2);b2 = b(3);
[rows_ref,cols_ref,channel_ref] = size(referenceImage);
[rows_ori,cols_ori,~] = size(originalImage);
correctedImage = zeros([rows_ref,cols_ref,channel_ref]);
for channel = 1 : channel_ref
    for row = 1 : rows_ref
        for col = 1 : cols_ref
            tempx = a0+a1*col+a2*row;
            tempy = b0+b1*col+b2*row;
            if tempx>=1 && tempx<=cols_ori && tempy>=1 && tempy<=rows_ori
                correctedImage(row,col,channel) = (tempx-floor(tempx))*(tempy-floor(tempy))*originalImage(ceil(tempy),ceil(tempx),channel)+(tempx-floor(tempx))*(ceil(tempy)-tempy)*originalImage(floor(tempy),ceil(tempx),channel)+(ceil(tempx)-tempx)*(tempy-floor(tempy))*originalImage(ceil(tempy),floor(tempx),channel)+(ceil(tempx)-tempx)*(ceil(tempy)-tempy)*originalImage(floor(tempy),floor(tempx),channel);
            end
        end
    end
end
end
