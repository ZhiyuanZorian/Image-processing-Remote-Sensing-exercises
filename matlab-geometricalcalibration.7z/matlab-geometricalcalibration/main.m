originalImage_path = 'src_image.tif';
referenceImage_path = 'ref_image.tif';
correctedImage = GeometricCorrection(originalImage_path,referenceImage_path);
imshow(correctedImage);